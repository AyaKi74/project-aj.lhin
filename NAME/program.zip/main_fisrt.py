import sqlite3
from tkinter import *
from tkinter import messagebox , simpledialog
from scores_A import *


root = Tk()
root.geometry("1280x720")
root.option_add('*Font','30')
root.title("Score Sheet Basketball")

edit_window = None 


db  = sqlite3.connect('teams.db')
conn = db.cursor()


def create_team_table():
    team_name = team_name_entry.get()
    conn.execute(f'''
    CREATE TABLE IF NOT EXISTS {team_name} 
    (   id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id TEXT,
        player_name TEXT,
        player_number INTEGER,
        position TEXT,
        scores INTEGER,
        UNIQUE(player_id))''')
    db.commit()
    showplayer()

# finish
def finish_botton():
    tamlaew()
    
button = Button(root, text="Finish", command=finish_botton)
button.place(x=1000,y=10)



def add_player():
    team_name_1 = team_name_entry.get()
    player_name = player_info_entries[0].get()
    player_number = int(player_info_entries[1].get())
    position = player_info_entries[2].get()

    player_id = f"{team_name_1}_{player_number}"


    conn.execute(f"INSERT INTO {team_name_1} (player_id, player_name, player_number, position) VALUES (?, ?, ?, ?)",
            (player_id, player_name, player_number, position))
    db.commit()
    showplayer()

def showplayer():
    team_name = team_name_entry.get()
    sql_cmd = f"SELECT * FROM {team_name}"
    players = db.execute(sql_cmd)
    listbox.delete(0, END)
    for player in players:
        listbox.insert(END,  player)
        

def on_click_edit_button():
    window_edit()

Label(root, text="ชื่อทีม:").grid(row=0, column=0)
team_name_entry = Entry(root,width=10)
team_name_entry.grid(row=0, column=1)


create_team_button_A = Button(root, text="สร้างตารางทีมA", command=create_team_table)
create_team_button_A.grid(row=0, column=2)




player_info_entries = []
player_info_labels = ["ชื่อผู้เล่น", "หมายเลขผู้เล่น", "ตำแหน่ง"]

for i, label_text in enumerate(player_info_labels):
    Label(root, text=label_text + ":").grid(row=i+1, column=0)
    entry = Entry(root)
    entry.grid(row=i+1, column=1)
    player_info_entries.append(entry)

add_player_button = Button(root, text="เพิ่มนักกีฬา", command=add_player)
add_player_button.grid()


listbox = Listbox(root,width=50,height=30)
listbox.place(x=700,y=100)

show_player_button = Button(root,text ="Refresh", command=showplayer)
show_player_button.grid()


edit_button = Button(root,text="edit", command=on_click_edit_button)
edit_button.grid()







#edit window 
def window_edit():
    global edit_window

    if edit_window is not None and edit_window.winfo_exists():
        edit_window.destroy()

    edit_window = Toplevel()
    edit_window.title("Score Sheet Basketball")
    edit_window.geometry("1280x720")

    id_var = StringVar()
    player_id_var = StringVar()
    name_var = StringVar()
    number_var = StringVar()
    position_var = StringVar()

    def showdata():
        team_name = team_name_entry.get()
        sql_cmd = f"SELECT * FROM {team_name}"
        players = conn.execute(sql_cmd)
        for item in players:
            Label(edit_window, text=item).pack(anchor="nw")
            e = Button(edit_window, text="Edit", command=lambda k=item[0]: edit_data(k))
            e.pack()
    def edit_data(selected_id):
        team_name = team_name_entry.get()
        sql_cmd = f"SELECT * FROM {team_name} WHERE id = ?"
        cursor = conn.execute(sql_cmd, (selected_id,))
        row = cursor.fetchone()

        id_var.set(row[0])
        player_id_var.set(row[1])
        name_var.set(row[2])
        number_var.set(row[3])
        position_var.set(row[4])

        e0 = Entry(edit_window, textvariable=id_var,state="readonly")
        e0.pack(side=LEFT)
        e1 = Entry(edit_window,textvariable=player_id_var)
        e1.pack(side = LEFT)
        e2 = Entry(edit_window, textvariable=name_var)
        e2.pack(side=LEFT)
        e3 = Entry(edit_window, textvariable=number_var)
        e3.pack(side=LEFT)
        e4 = Entry(edit_window, textvariable=position_var)
        e4.pack(side=LEFT)

        b2 = Button(edit_window, text="UPDATE", command=update_data)
        b2.pack(side=LEFT)
        b3 = Button(edit_window, text="Delete", command=delete_player)
        b3.pack(side=LEFT)

    def update_data():
        team_name = team_name_entry.get()
        data = (player_id_var.get(),name_var.get(), number_var.get(), position_var.get(), id_var.get())
        sql_cmd = f"UPDATE {team_name} SET player_id = ? ,player_name = ?, player_number = ?, position = ? WHERE id = ?"
        conn.execute(sql_cmd, data)
        db.commit()
        for widget in edit_window.winfo_children():
                widget.destroy()
        showdata()

    def delete_player():
        player_id = id_var.get()
        team_name = team_name_entry.get()
        sql_cmd = f"DELETE FROM {team_name} WHERE id = ?"
        decrement_cmd = f"UPDATE {team_name} SET id = id - 1 WHERE id > ?"

        try:
                cursor = db.cursor()
                cursor.execute(sql_cmd, (player_id,))
                cursor.execute(decrement_cmd, (player_id,))
                db.commit()
                for widget in edit_window.winfo_children():
                    widget.destroy()
                showdata()
        except sqlite3.Error as e:
            print("Error deleting player:", e)
            

    showdata()



root.mainloop()